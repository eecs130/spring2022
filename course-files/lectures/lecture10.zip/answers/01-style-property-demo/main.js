
const makeRed = (ev) => {
    document.querySelector('body').style.backgroundColor = 'red';
};

const makeBlue = (ev) => {
    document.querySelector('body').style.backgroundColor = 'blue';
};

const makePink = (ev) => {
    document.querySelector('body').style.backgroundColor = 'pink';
};

const makeOrange = (ev) => {
    document.querySelector('body').style.backgroundColor = 'orange';
};


// document.querySelector('#btn1').onclick = makeRed;
// document.querySelector('#btn2').onclick = makeBlue;
// document.querySelector('#btn3').onclick = makePink;
// document.querySelector('#btn4').onclick = makeOrange;