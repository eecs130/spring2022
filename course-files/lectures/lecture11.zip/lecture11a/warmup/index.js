const add_numbers = (ev) => {
    // Your code here...
    console.log('add the numbers...');
}

document.getElementById('add').onclick = add_numbers;