
const makeRed = (ev) => {
    // your code here...
};

const makeBlue = (ev) => {
    // your code here...
};

const makePink = (ev) => {
    // your code here...
};

const makeOrange = (ev) => {
    // your code here...
};


document.querySelector('#btn1').onclick = makeRed;
document.querySelector('#btn2').onclick = makeBlue;
document.querySelector('#btn3').onclick = makePink;
document.querySelector('#btn4').onclick = makeOrange;