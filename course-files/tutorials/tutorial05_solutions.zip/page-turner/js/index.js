ch1_text = `<h2>Chapter 1</h2>
<p>Lorem ipsum dolor sit amet, cu soluta concludaturque vim, summo voluptatibus ex sea. Est id aperiri offendit vulputate, legere malorum est et. Zril volutpat sit id, no aeterno apeirian mei. Est at oblique democritum. Oratio minimum atomorum an per, mel ne ferri deterruisset. In eos vivendum incorrupte reprimique...</p>`;

ch2_text = `<h2>Chapter 2</h2>
<p>Vel animal omittantur at, malis aperiri docendi eam cu. Usu ad tota omnesque, an alii gloriatur vis. Pri homero alienum voluptatibus no. Sea ne quot omnes, apeirian dignissim disputationi vim at.  Eu enim mutat volutpat est, tota partiendo expetenda ad mea. Ei nam epicuri pertinacia, alterum offendit maluisset ut est.</p>

<p>Duis vivendum dissentiunt nec ea. Sed at omittam sadipscing, est ea dolore verear vituperata, blandit suscipit intellegat ex nec. Idque essent eu est.</p>`;

ch3_text = `<h2>Chapter 3</h2>
<p>Libris persecuti in ius, sed id probo molestie. Ut est habemus legendos facilisis, per id nostrud vivendo phaedrum. Qui dolores nominati te. Id nam legendos necessitatibus, ne vim malis choro soleat, te cum porro decore. Utinam antiopam dissentiunt eam ei, vim enim reque omittantur an.</p>

<p>Virtute quaeque omnesque vis no, pro id omnes torquatos, paulo audiam pri ne. Eirmod malorum partiendo vel id, impedit alienum omittantur ne vix, ne usu libris accumsan platonem. Suavitate dissentias sit at, vis vivendo interesset eu. Ei intellegat moderatius quo, at mel elit fierent. Cu quaeque efficiendi nec, per et autem viris, sit in luptatum platonem. Sea diam reprimique ad, aliquip meliore constituto has et.</p>`;

const chapter1 = () => {
   document.querySelector('.content').innerHTML = ch1_text;
};

const chapter2 = () => {
   document.querySelector('.content').innerHTML = ch2_text;
};

const chapter3 = () => {
   document.querySelector('.content').innerHTML = ch3_text;
};



document.querySelector('#ch1').onmouseover = chapter1;
document.querySelector('#ch2').onmouseover = chapter2;
document.querySelector('#ch3').onmouseover = chapter3;
